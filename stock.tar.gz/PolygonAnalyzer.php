<?php

class PolygonAnalyzer {
    private $apiKey;
    private $baseUrl = 'https://api.polygon.io/v2';
    private $dataDir = './tickers/';
    private $cngn;

    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
        $this->cngn = new CNGN(5);
    }

    public function analyzeTicker($ticker) {
        $filePath = $this->dataDir . $ticker;
        
        if (!file_exists($filePath . '.json') || $this->isFileOld($filePath . '.json')) {
            $this->fetchTickerData($ticker);
        }

        /**
         * Analyzes the ticker data for the given file path and returns the Bitcoin analysis.
         *
         * @param string $filePath The file path containing the ticker data.
         * @return array The Bitcoin analysis for the ticker data.
         */
        $rets_sofar = $this->cngn->bitcoin($filePath);
        echo "<table style='width:100%;margin-top:45px;position:fixed;float:right;z-index:-1;'><tr><td style='width:60%;background-color:blue;color:white'>// ".$ticker."</td>";
        echo "<td style='width:20%;background-color:purple;color:white'><pipe id='cntr' ajax='counter.php' style='color:white' insert='cntr'></td>";
        echo "<td style='background-color:red;color:white'>".round($rets[1]*100,2)."% Accuracy</td></tr></table><hr>";
        echo "<b style='margin-top:10px;margin-left:85%;position:absolute;float:right'>". $rets_sofar[2]."</b>";
        echo "<br><Br><br>" . $rets_sofar[1] . "% accuracy";
        echo "<table style='width:100%;z-index:-1'>";
        echo $rets_sofar[0]; //."</td><td>".$rets_today[0]."</td></tr>";    
        echo "</table>";
    }


    private function fetchTickerData($ticker) {
        $endDate = date('Y-m-d');
        $startDate = date('Y-m-d', strtotime('-60 days'));
        $ticker = explode('.', $ticker)[0];
        $url = "curl '{$this->baseUrl}/aggs/ticker/{$ticker}/range/1/day/{$startDate}/{$endDate}?apiKey={$this->apiKey}&format=csv' -o ./tickers/{$ticker}.json";

        $csvData = exec($url);
    }

    private function isFileOld($filePath) {
        $fileAge = time() - filemtime($filePath);
        return $fileAge > (60 * 24 * 60 * 60); // 60 days in seconds
    }
}
?>