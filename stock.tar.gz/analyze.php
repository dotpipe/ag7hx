<?php
require_once 'btc.php';
require_once 'PolygonAnalyzer.php';

$apiKey = 'yB0m7BdNgmQ_hlU6MQxahE83l1Hlxppy';
$analyzer = new PolygonAnalyzer($apiKey);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ticker'])) {
    $ticker = strtoupper($_POST['ticker']);
    $result = $analyzer->analyzeTicker($ticker);
    
    // Process and display the result
    print_r($result);
}