<?php
// require_once 'btc.php';
// require_once 'PolygonAnalyzer.php';

// $apiKey = 'yB0m7BdNgmQ_hlU6MQxahE83l1Hlxppy';
// $analyzer = new PolygonAnalyzer($apiKey);

// if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ticker'])) {
//     $ticker = strtoupper($_POST['ticker']);
//     $result = $analyzer->analyzeTicker($ticker);
    
//     // Process and display the result
//     print_r($result);

require_once 'PolygonAnalyzer.php';

$apiKey = 'yB0m7BdNgmQ_hlU6MQxahE83l1Hlxppy';
$analyzer = new PolygonAnalyzer($apiKey);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticker = isset($_POST['ticker']) ? strtoupper($_POST['ticker']) : '';
    $removeCount = isset($_POST['remove_count']) ? intval($_POST['remove_count']) : 0;

    if (!empty($ticker)) {
        $fullResult = $analyzer->analyzeTicker($ticker, 0);
        $shiftedResult = $analyzer->analyzeTicker($ticker, $removeCount);
    }
    echo "<div style='display: flex;'>";
    echo "<div style='flex: 1;'>";
    echo "<h2>Shifted Data (Removed: $removeCount)</h2>";
    echo $shiftedResult;  // Display the shifted data output
    echo "</div>";
    
    echo "<div style='flex: 1;'>";
    echo "<h2>Full Data</h2>";
    echo $fullResult;  // Display the full data output
    echo "</div>";
    echo "</div>";
}